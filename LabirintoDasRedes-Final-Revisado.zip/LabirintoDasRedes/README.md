# Labirinto das Redes — Projeto Final de POO

## Como abrir no IntelliJ IDEA
1. Extraia o arquivo `.zip` em uma pasta no seu computador.
2. Abra o **IntelliJ IDEA** -> **File > Open** -> selecione a pasta `LabirintoDasRedes`.
3. Execute a classe `Main.java` (botão verde de Play ao lado de `public static void main`).

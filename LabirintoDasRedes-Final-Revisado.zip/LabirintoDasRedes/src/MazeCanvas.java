import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;
import java.util.List;

public class MazeCanvas extends JPanel {
    private static final int TILE = 36;
    private final Game game;
    private final List<Point> trail = new ArrayList<>();
    private float pulsePhase = 0f;

    public MazeCanvas(Game game) {
        this.game = game;
        setPreferredSize(new Dimension(
                game.getMazeMap().getCols() * TILE,
                game.getMazeMap().getRows() * TILE
        ));
        setBackground(new Color(9, 13, 24));
        setOpaque(true);
        setFocusable(true);

        Timer animTimer = new Timer(33, e -> {
            pulsePhase += 0.12f;
            if (pulsePhase > Math.PI * 2) pulsePhase -= (float) (Math.PI * 2);
            repaint();
        });
        animTimer.start();
    }

    public void movePlayer(int dx, int dy) {
        int oldX = game.getPlayerX();
        int oldY = game.getPlayerY();
        if (game.movePlayer(dx, dy)) {
            trail.add(new Point(oldX, oldY));
            if (trail.size() > 14) {
                trail.remove(0);
            }
        }
        repaint();
    }

    public void clearTrail() {
        trail.clear();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        RadialGradientPaint bgGrad = new RadialGradientPaint(
                new Point2D.Float(w / 2f, h / 2f),
                Math.max(w, h) * 0.7f,
                new float[]{0f, 1f},
                new Color[]{new Color(15, 24, 44), new Color(6, 9, 18)}
        );
        g.setPaint(bgGrad);
        g.fillRect(0, 0, w, h);

        drawCircuitBackground(g, w, h);

        MazeMap map = game.getMazeMap();
        List<Room> rooms = game.getRooms();
        int currentRoomIdx = rooms.indexOf(game.getPlayer().getCurrentRoom());

        for (int y = 0; y < map.getRows(); y++) {
            for (int x = 0; x < map.getCols(); x++) {
                int px = x * TILE;
                int py = y * TILE;
                int roomIdx = map.getRoomIndex(x, y);

                if (roomIdx < 0) {
                    g.setColor(new Color(13, 20, 36, 210));
                    g.fillRoundRect(px + 2, py + 2, TILE - 4, TILE - 4, 6, 6);
                    g.setColor(new Color(26, 41, 70));
                    g.drawRoundRect(px + 2, py + 2, TILE - 4, TILE - 4, 6, 6);
                } else {
                    Room r = rooms.get(roomIdx);
                    boolean isCurrentRoom = (roomIdx == currentRoomIdx);
                    Color base = getRoomBaseColor(r);
                    Color accent = getRoomAccentColor(r);

                    g.setColor(isCurrentRoom ? brighten(base, 22) : base);
                    g.fillRoundRect(px + 1, py + 1, TILE - 2, TILE - 2, 6, 6);

                    g.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), isCurrentRoom ? 150 : 55));
                    g.setStroke(new BasicStroke(isCurrentRoom ? 1.5f : 1f));
                    g.drawRoundRect(px + 1, py + 1, TILE - 2, TILE - 2, 6, 6);
                }
            }
        }

        drawNetworkLinks(g, map, rooms);
        drawRoomDecorations(g, map, rooms);
        drawPlayerTrail(g);
        drawPacketPlayer(g);

        if (game.getRemainingSeconds() <= 30 || (game.getMaxHops() - game.getHops()) <= 12) {
            float alpha = (float) (0.18 + 0.14 * Math.sin(pulsePhase * 2.5));
            g.setColor(new Color(239, 68, 68, (int) (alpha * 255)));
            g.setStroke(new BasicStroke(8f));
            g.drawRect(4, 4, w - 8, h - 8);
        }
    }

    private void drawCircuitBackground(Graphics2D g, int w, int h) {
        g.setColor(new Color(20, 35, 62, 90));
        g.setStroke(new BasicStroke(1f));
        for (int x = 0; x < w; x += TILE) {
            g.drawLine(x, 0, x, h);
        }
        for (int y = 0; y < h; y += TILE) {
            g.drawLine(0, y, w, y);
        }
    }

    private void drawNetworkLinks(Graphics2D g, MazeMap map, List<Room> rooms) {
        int[][] links = {
                {0, 1}, {1, 2}, {1, 4}, {2, 7}, {2, 3}, {3, 8}, {3, 5}, {5, 6}
        };
        float dashPhase = Math.abs(pulsePhase * 6f);
        Stroke dashed = new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                0, new float[]{5f, 5f}, dashPhase);
        g.setStroke(dashed);

        for (int[] link : links) {
            Point p1 = map.getRoomCenter(link[0]);
            Point p2 = map.getRoomCenter(link[1]);
            Room target = rooms.get(link[1]);

            Color linkColor = new Color(56, 189, 248, 85);
            if (target instanceof LockedRoom locked && !locked.canEnter(game.getPlayer())) {
                linkColor = new Color(248, 113, 113, 110);
            } else if (target instanceof LockedRoom) {
                linkColor = new Color(74, 222, 128, 120);
            }
            g.setColor(linkColor);
            g.drawLine(p1.x * TILE + TILE / 2, p1.y * TILE + TILE / 2,
                       p2.x * TILE + TILE / 2, p2.y * TILE + TILE / 2);
        }
        g.setStroke(new BasicStroke(1f));
    }

    private void drawRoomDecorations(Graphics2D g, MazeMap map, List<Room> rooms) {
        String[] shortNames = {
                "ESTAÇÃO", "BACKBONE", "SWITCH L3", "FIREWALL",
                "ROTEADOR (!)", "DATACENTER", "GATEWAY", "DNS CACHE", "PROXY NAT"
        };
        int[][] labelTiles = {
                {1, 1}, {4, 2}, {8, 1}, {9, 4},
                {5, 5}, {12, 5}, {18, 5}, {13, 1}, {9, 8}
        };

        for (int i = 0; i < rooms.size(); i++) {
            Room r = rooms.get(i);
            Point c = map.getRoomCenter(i);
            int cx = c.x * TILE + TILE / 2;
            int cy = c.y * TILE + TILE / 2;

            drawRoomTag(g, shortNames[i], labelTiles[i][0] * TILE + 4, labelTiles[i][1] * TILE + 4, getRoomAccentColor(r));

            if (r instanceof LockedRoom locked) {
                boolean unlocked = locked.canEnter(game.getPlayer());
                drawLockIcon(g, cx - 10, cy + 4, unlocked);
            } else if (r instanceof FaultyRouterRoom) {
                drawSparkIcon(g, cx - 10, cy + 4);
            } else if (r instanceof RandomTunnelRoom) {
                drawPortalIcon(g, cx - 10, cy + 4);
            } else if (i == 5) {
                drawServerRackIcon(g, cx - 10, cy + 4);
            }

            if (r.hasItems()) {
                float scale = 1.0f + 0.18f * (float) Math.sin(pulsePhase * 1.8);
                int size = Math.round(11 * scale);
                int ix = cx + 8 - size / 2;
                int iy = cy + 6 - size / 2;

                g.setColor(new Color(251, 191, 36, 70));
                g.fillOval(ix - 4, iy - 4, size + 8, size + 8);

                g.setColor(new Color(251, 191, 36));
                g.fillRoundRect(ix, iy, size, size, 4, 4);
                g.setColor(Color.WHITE);
                g.drawRoundRect(ix, iy, size, size, 4, 4);
            }

            if (r.getChallenge() != null && !r.getChallenge().isSolved()) {
                g.setColor(new Color(239, 68, 68));
                g.fillOval(cx - 14, cy - 12, 12, 12);
                g.setColor(Color.WHITE);
                g.setFont(new Font("SansSerif", Font.BOLD, 9));
                g.drawString("!", cx - 10, cy - 3);
            }
        }
    }

    private void drawRoomTag(Graphics2D g, String text, int x, int y, Color accent) {
        g.setFont(new Font("SansSerif", Font.BOLD, 9));
        FontMetrics fm = g.getFontMetrics();
        int pad = 4;
        int w = fm.stringWidth(text) + pad * 2;
        int h = fm.getHeight();

        g.setColor(new Color(10, 15, 28, 200));
        g.fillRoundRect(x, y, w, h, 6, 6);
        g.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 160));
        g.drawRoundRect(x, y, w, h, 6, 6);

        g.setColor(accent);
        g.drawString(text, x + pad, y + fm.getAscent());
    }

    private void drawLockIcon(Graphics2D g, int x, int y, boolean unlocked) {
        Color c = unlocked ? new Color(74, 222, 128) : new Color(248, 113, 113);
        g.setColor(c);
        g.fillRoundRect(x, y + 4, 10, 8, 2, 2);
        g.setStroke(new BasicStroke(1.5f));
        if (unlocked) {
            g.drawArc(x + 4, y, 6, 7, 0, 180);
        } else {
            g.drawArc(x + 2, y, 6, 7, 0, 180);
        }
    }

    private void drawSparkIcon(Graphics2D g, int x, int y) {
        g.setColor(new Color(251, 146, 60));
        int[] xs = {x + 5, x + 1, x + 5, x + 3, x + 9, x + 5};
        int[] ys = {y, y + 6, y + 6, y + 12, y + 5, y + 5};
        g.fillPolygon(xs, ys, 6);
    }

    private void drawPortalIcon(Graphics2D g, int x, int y) {
        g.setColor(new Color(192, 132, 252));
        g.setStroke(new BasicStroke(1.6f));
        g.drawOval(x, y, 11, 11);
        g.drawOval(x + 3, y + 3, 5, 5);
    }

    private void drawServerRackIcon(Graphics2D g, int x, int y) {
        g.setColor(new Color(56, 189, 248));
        g.fillRect(x, y, 11, 4);
        g.fillRect(x, y + 6, 11, 4);
        boolean blink = Math.sin(pulsePhase * 3) > 0;
        g.setColor(blink ? new Color(74, 222, 128) : new Color(250, 204, 21));
        g.fillOval(x + 2, y + 1, 2, 2);
        g.fillOval(x + 2, y + 7, 2, 2);
    }

    private void drawPlayerTrail(Graphics2D g) {
        for (int i = 0; i < trail.size(); i++) {
            Point p = trail.get(i);
            float ratio = (float) (i + 1) / trail.size();
            int alpha = (int) (ratio * 95);
            int size = (int) (8 + ratio * 8);
            int cx = p.x * TILE + TILE / 2 - size / 2;
            int cy = p.y * TILE + TILE / 2 - size / 2;

            g.setColor(new Color(56, 189, 248, alpha));
            g.fillOval(cx, cy, size, size);
        }
    }

    private void drawPacketPlayer(Graphics2D g) {
        int px = game.getPlayerX() * TILE;
        int py = game.getPlayerY() * TILE;
        int cx = px + TILE / 2;
        int cy = py + TILE / 2;

        int glow = 26 + (int) (4 * Math.sin(pulsePhase * 2));
        g.setColor(new Color(56, 189, 248, 75));
        g.fillOval(cx - glow / 2, cy - glow / 2, glow, glow);

        GradientPaint pktGrad = new GradientPaint(
                px + 6, py + 6, new Color(56, 189, 248),
                px + TILE - 6, py + TILE - 6, new Color(37, 99, 235)
        );
        g.setPaint(pktGrad);
        g.fillOval(px + 6, py + 6, TILE - 12, TILE - 12);

        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(2f));
        g.drawOval(px + 6, py + 6, TILE - 12, TILE - 12);

        g.setFont(new Font("Monospaced", Font.BOLD, 11));
        g.drawString("IP", cx - 7, cy + 4);
    }

    private Color getRoomBaseColor(Room room) {
        if (room instanceof LockedRoom locked) {
            return locked.canEnter(game.getPlayer())
                    ? new Color(16, 48, 42)
                    : new Color(55, 22, 32);
        }
        if (room instanceof FaultyRouterRoom) {
            return new Color(56, 40, 18);
        }
        if (room instanceof RandomTunnelRoom) {
            return new Color(44, 24, 66);
        }
        return new Color(24, 38, 64);
    }

    private Color getRoomAccentColor(Room room) {
        if (room instanceof LockedRoom locked) {
            return locked.canEnter(game.getPlayer())
                    ? new Color(74, 222, 128)
                    : new Color(248, 113, 113);
        }
        if (room instanceof FaultyRouterRoom) {
            return new Color(251, 191, 36);
        }
        if (room instanceof RandomTunnelRoom) {
            return new Color(192, 132, 252);
        }
        return new Color(125, 211, 252);
    }

    private Color brighten(Color c, int amount) {
        return new Color(
                Math.min(255, c.getRed() + amount),
                Math.min(255, c.getGreen() + amount),
                Math.min(255, c.getBlue() + amount)
        );
    }
}

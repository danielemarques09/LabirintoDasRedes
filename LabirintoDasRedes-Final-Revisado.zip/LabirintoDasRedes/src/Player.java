import java.util.ArrayList;
import java.util.List;

public class Player {
    private Room currentRoom;
    private int x;
    private int y;
    private final List<Item> inventory = new ArrayList<>();
    private final int mtu;
    private int currentWeight;

    public Player(Room startingRoom, int startX, int startY, int mtu) {
        this.currentRoom = startingRoom;
        this.x = startX;
        this.y = startY;
        this.mtu = mtu;
        this.currentWeight = 0;
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(Room room) {
        this.currentRoom = room;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String takeItem(String name) {
        if (name == null || name.isBlank()) {
            return "Informe o nome do item para pegar.";
        }
        Item item = currentRoom.getItem(name);
        if (item == null) {
            return "O item '" + name + "' não está nesta sala.";
        }
        if (currentWeight + item.getWeight() > mtu) {
            return "MTU EXCEDIDO! '" + item.getName() + "' pesa " + item.getWeight()
                    + "B e você só tem " + (mtu - currentWeight) + "B livres. Solte algo antes!";
        }
        inventory.add(item);
        currentWeight += item.getWeight();
        currentRoom.removeItem(name);
        return "Você coletou '" + item.getName() + "'. MTU atual: " + currentWeight + "/" + mtu + " bytes.";
    }

    public String dropItem(String name) {
        if (name == null || name.isBlank()) {
            return "Informe o nome do item para soltar.";
        }
        Item item = getItem(name);
        if (item == null) {
            return "Você não possui '" + name + "' no inventário.";
        }
        inventory.remove(item);
        currentWeight -= item.getWeight();
        currentRoom.addItem(item);
        return "Você soltou '" + item.getName() + "' na sala. MTU atual: " + currentWeight + "/" + mtu + " bytes.";
    }

    public Item getItem(String name) {
        if (name == null) return null;
        for (Item item : inventory) {
            if (item.getName().equalsIgnoreCase(name.trim())) {
                return item;
            }
        }
        return null;
    }

    public boolean hasItem(String name) {
        return getItem(name) != null;
    }

    public boolean consumeItem(String name) {
        Item item = getItem(name);
        if (!(item instanceof ConsumableItem)) {
            return false;
        }
        inventory.remove(item);
        currentWeight -= item.getWeight();
        return true;
    }

    public int getCurrentWeight() {
        return currentWeight;
    }

    public int getMtu() {
        return mtu;
    }

    public List<Item> getInventory() {
        return new ArrayList<>(inventory);
    }

    public String getInventoryString() {
        if (inventory.isEmpty()) {
            return "Inventário vazio.\nCapacidade MTU: 0/" + mtu + " bytes";
        }
        StringBuilder text = new StringBuilder("Itens carregados:\n");
        for (Item item : inventory) {
            text.append("• ").append(item).append("\n");
        }
        text.append("\nCapacidade MTU: ").append(currentWeight).append("/").append(mtu).append(" bytes");
        return text.toString();
    }
}

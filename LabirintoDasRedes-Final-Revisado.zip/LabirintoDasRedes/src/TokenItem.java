public class TokenItem extends Item {
    public TokenItem() {
        super("token", "Token de sessão JWT para atravessar o Firewall", 15);
    }

    @Override
    public String use(Player player, Game game) {
        return "Token JWT ativo: permite atravessar o Firewall enquanto estiver no inventário.";
    }
}

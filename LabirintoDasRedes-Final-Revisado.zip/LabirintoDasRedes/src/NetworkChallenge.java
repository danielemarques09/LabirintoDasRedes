public class NetworkChallenge {
    private final String prompt;
    private final String expectedAnswer;
    private final String hint;
    private boolean solved;

    public NetworkChallenge(String prompt, String expectedAnswer, String hint) {
        this.prompt = prompt;
        this.expectedAnswer = expectedAnswer;
        this.hint = hint;
        this.solved = false;
    }

    public String getPrompt() {
        return prompt;
    }

    public String getHint() {
        return hint;
    }

    public boolean isSolved() {
        return solved;
    }

    public boolean checkAnswer(String response) {
        if (response != null && expectedAnswer.equalsIgnoreCase(response.trim())) {
            this.solved = true;
            return true;
        }
        return false;
    }
}

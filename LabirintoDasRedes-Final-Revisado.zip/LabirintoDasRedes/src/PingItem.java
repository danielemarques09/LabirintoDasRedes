public class PingItem extends ConsumableItem {
    public PingItem() {
        super("ping", "Pacote ICMP de diagnóstico: revela portas/saídas e testa conexões da sala atual", 5);
    }

    @Override
    protected String applyEffect(Player player, Game game) {
        Room current = player.getCurrentRoom();
        String exits = current.getExitsDescription();
        String items = current.getItemString();
        String challengeInfo = (current.getChallenge() != null && !current.getChallenge().isSolved())
                ? " [ALERTA: Há um desafio de rede ativo nesta sala!]"
                : " [Nenhum bloqueio lógico ativo.]";

        return "ICMP ECHO REPLY de " + current.getName() + " (TTL=64, 2ms): Saídas = "
                + exits + " | Itens detectados = " + items + challengeInfo;
    }
}

import java.util.List;

public class CommandWords {
    private static final List<String> VALID_COMMANDS = List.of(
            "ir", "pegar", "soltar", "solta", "inventario", "inventário",
            "usar", "responder", "olhar", "dica", "ajuda", "sair"
    );

    public boolean isCommand(String word) {
        return word != null && VALID_COMMANDS.contains(word.toLowerCase());
    }

    public String showAll() {
        return "ir, pegar, soltar, inventario, usar, responder, olhar, dica, ajuda, sair";
    }
}

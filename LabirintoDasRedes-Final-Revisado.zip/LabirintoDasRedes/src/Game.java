import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Game {
    private Player player;
    private final List<Room> rooms = new ArrayList<>();
    private final MazeMap mazeMap = new MazeMap();
    private final Parser parser = new Parser();
    private final Random random = new Random();

    private int hops = 0;
    private final int maxHops = 90;
    private long startTime = System.currentTimeMillis();
    private final long timeLimitMillis = 240_000;

    private boolean finished;
    private boolean victory;
    private String status = "Missão iniciada! Colete itens, explore a rede e chegue ao Gateway com a chave.";
    private final List<String> eventLog = new ArrayList<>();

    public Game() {
        resetGame();
    }

    public final void resetGame() {
        rooms.clear();
        eventLog.clear();
        hops = 0;
        startTime = System.currentTimeMillis();
        finished = false;
        victory = false;
        status = "Missão iniciada! Colete itens, explore a rede e chegue ao Gateway com a chave.";
        createRooms();
        logEvent("Sistema sob ataque de ransomware! Limite de MTU do pacote: 50 bytes.");
        logEvent(status);
    }

    private void createRooms() {
        Room start = new Room("Estação de Trabalho",
                "Ponto de origem do pacote. Há um diagnóstico Ping disponível.");
        Room corridor = new Room("Corredor Principal",
                "Backbone interno da LAN. Um Token JWT está caído próximo ao rack.");
        Room switchRoom = new Room("Sala do Switch",
                "Switch Layer 3 gerenciável. O tráfego para o sul está bloqueado por política de roteamento.");
        LockedRoom firewall = new LockedRoom("Firewall",
                "Barreira de inspeção de pacotes. Exige Token de autenticação.", "token");
        FaultyRouterRoom deadEnd = new FaultyRouterRoom("Roteador Defeituoso",
                "Hardware superaquecido! Causa perda de pacotes (+3 saltos), mas guarda um Log do sistema.", 3);
        Room servers = new Room("Sala dos Servidores",
                "Datacenter local onde fica armazenada a Chave de Segurança AES-256.");
        LockedRoom gateway = new LockedRoom("Gateway de Saída",
                "Roteador de borda para a Nuvem. Exige a Chave de Segurança para escapar.", "chave");
        Room dnsServer = new Room("Servidor DNS & Cache",
                "Servidor auxiliar com pacotes de cache e ferramentas de QoS.");
        RandomTunnelRoom proxyTunnel = new RandomTunnelRoom("Túnel Proxy NAT",
                "Túnel dinâmico instável! Redireciona o pacote aleatoriamente pela rede.");

        start.setExit("leste", corridor);

        corridor.setExit("oeste", start);
        corridor.setExit("leste", switchRoom);
        corridor.setExit("sul", deadEnd);

        deadEnd.setExit("norte", corridor);

        switchRoom.setExit("oeste", corridor);
        switchRoom.setExit("leste", dnsServer);
        switchRoom.setExit("sul", firewall);

        dnsServer.setExit("oeste", switchRoom);

        firewall.setExit("norte", switchRoom);
        firewall.setExit("sul", proxyTunnel);
        firewall.setExit("leste", servers);

        proxyTunnel.setExit("norte", firewall);

        servers.setExit("oeste", firewall);
        servers.setExit("leste", gateway);

        gateway.setExit("oeste", servers);

        start.addItem(new PingItem());
        corridor.addItem(new TokenItem());
        corridor.addItem(new JunkPacketItem());
        deadEnd.addItem(new CorruptedLogItem());
        dnsServer.addItem(new PacketBoosterItem());
        servers.addItem(new SecurityKey());

        switchRoom.setChallenge(new NetworkChallenge(
                "Configure a rota padrão: qual é o IPv4 do Gateway indicado no Log?",
                "192.168.10.254",
                "Investigue o Roteador Defeituoso ao sul do Corredor para achar o Log."
        ));

        servers.setChallenge(new NetworkChallenge(
                "Autenticação TLS do Datacenter: qual porta padrão o protocolo HTTPS utiliza?",
                "443",
                "A porta segura também está registrada no arquivo de Log."
        ));

        rooms.add(start);
        rooms.add(corridor);
        rooms.add(switchRoom);
        rooms.add(firewall);
        rooms.add(deadEnd);
        rooms.add(servers);
        rooms.add(gateway);
        rooms.add(dnsServer);
        rooms.add(proxyTunnel);

        Point spawn = mazeMap.getRoomCenter(0);
        player = new Player(start, spawn.x, spawn.y, 50);
    }

    public boolean movePlayer(int dx, int dy) {
        if (finished) return false;
        checkLimits();
        if (finished) return false;

        int nx = player.getX() + dx;
        int ny = player.getY() + dy;

        if (!mazeMap.isWalkable(nx, ny)) {
            updateStatus("Parede/Rack bloqueando passagem nessa direção.");
            return false;
        }

        int currentRoomIndex = rooms.indexOf(player.getCurrentRoom());
        int targetRoomIndex = mazeMap.getRoomIndex(nx, ny);
        Room current = player.getCurrentRoom();
        Room target = rooms.get(targetRoomIndex);

        if (targetRoomIndex != currentRoomIndex) {
            if (!current.hasExitTo(target)) {
                updateStatus("Não há enlace de rede direto para essa sala.");
                return false;
            }

            NetworkChallenge challenge = current.getChallenge();
            if (challenge != null && !challenge.isSolved()) {
                updateStatus("BLOQUEADO: Resolva o desafio de '" + current.getName() + "' antes de avançar!");
                return false;
            }

            if (!target.canEnter(player)) {
                updateStatus(target.getBlockedMessage());
                return false;
            }

            player.setCurrentRoom(target);
            player.setPosition(nx, ny);
            hops++;

            String enterMsg = target.onEnter(player, this);
            updateStatus(enterMsg);
            checkLimits();

            if (targetRoomIndex == 6 && !finished) {
                victory = true;
                finished = true;
                updateStatus("MISSÃO CONCLUÍDA! Pacote escapou pelo Gateway para a Nuvem com a Chave AES!");
            }
            return true;
        }

        player.setPosition(nx, ny);
        hops++;
        checkLimits();
        return true;
    }

    public String teleportPlayerRandomly() {
        int[] safeRooms = {0, 1, 2, 7};
        int chosenIndex = safeRooms[random.nextInt(safeRooms.length)];
        Room destination = rooms.get(chosenIndex);
        Point center = mazeMap.getRoomCenter(chosenIndex);

        player.setCurrentRoom(destination);
        player.setPosition(center.x, center.y);
        return "TÚNEL PROXY NAT! Seu pacote foi roteado aleatoriamente para: " + destination.getName() + "!";
    }

    public void executeCommand(String input) {
        if (finished) {
            updateStatus("A partida já encerrou. Clique em 'Reiniciar Rede' para jogar novamente.");
            return;
        }
        checkLimits();
        if (finished) return;

        Command command = parser.parse(input);
        if (command.isUnknown()) {
            updateStatus("Comando desconhecido. Digite 'ajuda' para ver a lista.");
            return;
        }

        String word = command.getCommandWord();
        String arg = command.getSecondWord();

        switch (word) {
            case "ir" -> moveByDirection(arg);
            case "pegar" -> updateStatus(player.takeItem(arg));
            case "soltar", "solta" -> updateStatus(player.dropItem(arg));
            case "inventario", "inventário" -> updateStatus(player.getInventoryString().replace("\n", " | "));
            case "usar" -> useItem(arg);
            case "responder" -> solveChallenge(arg);
            case "olhar" -> updateStatus(player.getCurrentRoom().getLongDescription().replace("\n", " | "));
            case "dica" -> showHint();
            case "ajuda" -> updateStatus("Comandos: " + parser.getCommands());
            case "sair" -> gameOver("Você abortou a transmissão do pacote.");
            default -> updateStatus("Comando inválido.");
        }
    }

    private void moveByDirection(String direction) {
        if (direction == null) {
            updateStatus("Informe a direção: norte, sul, leste ou oeste.");
            return;
        }
        switch (direction) {
            case "norte" -> movePlayer(0, -1);
            case "sul" -> movePlayer(0, 1);
            case "leste" -> movePlayer(1, 0);
            case "oeste" -> movePlayer(-1, 0);
            default -> updateStatus("Direção inválida. Use norte, sul, leste ou oeste.");
        }
    }

    private void useItem(String name) {
        if (name == null) {
            updateStatus("Informe o nome do item para usar (ex: usar ping, usar log).");
            return;
        }
        Item item = player.getItem(name);
        if (item == null) {
            NetworkChallenge challenge = player.getCurrentRoom().getChallenge();
            if (challenge != null && !challenge.isSolved()) {
                solveChallenge(name);
                return;
            }
            updateStatus("Você não possui '" + name + "' no inventário.");
            return;
        }
        updateStatus(item.use(player, this));
    }

    public boolean solveChallenge(String answer) {
        if (finished) return false;
        NetworkChallenge challenge = player.getCurrentRoom().getChallenge();
        if (challenge == null) {
            updateStatus("Não há desafio de rede nesta sala.");
            return false;
        }
        if (challenge.isSolved()) {
            updateStatus("O desafio desta sala já foi resolvido!");
            return true;
        }
        if (answer == null || answer.isBlank()) {
            updateStatus("Desafio: " + challenge.getPrompt());
            return false;
        }
        if (challenge.checkAnswer(answer)) {
            updateStatus("SUCESSO! Desafio resolvido (" + answer.trim() + "). Passagem liberada!");
            return true;
        }
        addPenaltyHops(2);
        updateStatus("Resposta incorreta! Firewall penalizou +2 saltos. Dica: " + challenge.getHint());
        checkLimits();
        return false;
    }

    private void showHint() {
        NetworkChallenge challenge = player.getCurrentRoom().getChallenge();
        if (challenge != null && !challenge.isSolved()) {
            updateStatus("DICA DO DESAFIO: " + challenge.getHint());
        } else {
            updateStatus("DICA GERAL: Pegue o Log no Roteador ao sul, o Token no corredor, resolva o Switch e pegue a Chave nos Servidores.");
        }
    }

    public void addPenaltyHops(int extra) {
        this.hops += extra;
    }

    public void reduceHops(int saved) {
        this.hops = Math.max(0, this.hops - saved);
    }

    private void checkLimits() {
        if (finished) return;
        if (hops >= maxHops) {
            gameOver("GAME OVER! Limite de saltos (TTL) atingido. O ransomware criptografou a rede!");
            return;
        }
        if (System.currentTimeMillis() - startTime >= timeLimitMillis) {
            gameOver("GAME OVER! Tempo esgotado. O ransomware bloqueou todos os servidores!");
        }
    }

    private void gameOver(String message) {
        finished = true;
        victory = false;
        updateStatus(message);
    }

    private void updateStatus(String msg) {
        this.status = msg;
        logEvent(msg);
    }

    private void logEvent(String msg) {
        eventLog.add("> " + msg);
        if (eventLog.size() > 40) {
            eventLog.remove(0);
        }
    }

    public int getRemainingSeconds() {
        long remaining = Math.max(0, timeLimitMillis - (System.currentTimeMillis() - startTime));
        if (remaining == 0 && !finished) {
            gameOver("GAME OVER! Tempo esgotado. O ransomware bloqueou todos os servidores!");
        }
        return (int) (remaining / 1000);
    }

    public Player getPlayer() { return player; }
    public MazeMap getMazeMap() { return mazeMap; }
    public List<Room> getRooms() { return rooms; }
    public int getPlayerX() { return player.getX(); }
    public int getPlayerY() { return player.getY(); }
    public int getHops() { return hops; }
    public int getMaxHops() { return maxHops; }
    public boolean isFinished() { return finished; }
    public boolean isVictory() { return victory; }
    public String getStatus() { return status; }
    public List<String> getEventLog() { return eventLog; }
}

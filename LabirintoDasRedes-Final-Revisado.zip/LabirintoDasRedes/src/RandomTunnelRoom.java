public class RandomTunnelRoom extends Room {
    public RandomTunnelRoom(String name, String description) {
        super(name, description);
    }

    @Override
    public String onEnter(Player player, Game game) {
        return game.teleportPlayerRandomly();
    }
}

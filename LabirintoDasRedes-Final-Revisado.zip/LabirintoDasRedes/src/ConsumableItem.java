public abstract class ConsumableItem extends Item {
    protected ConsumableItem(String name, String description, int weight) {
        super(name, description, weight);
    }

    @Override
    public final String use(Player player, Game game) {
        String result = applyEffect(player, game);
        player.consumeItem(getName());
        return result;
    }

    protected abstract String applyEffect(Player player, Game game);
}

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GamePanel extends JPanel {
    private final Game game;
    private final MazeCanvas mazeCanvas;

    private JProgressBar hopsBar;
    private JProgressBar timeBar;
    private JProgressBar mtuBar;

    private JLabel roomLabel;
    private JLabel roomDetailLabel;
    private JTextArea logArea;
    private JTextField commandField;
    private Timer timer;
    private boolean resultShown;

    private static final Color BG_DARK = new Color(9, 13, 24);
    private static final Color PANEL_BG = new Color(15, 23, 42);
    private static final Color BORDER_CYAN = new Color(30, 58, 95);
    private static final Color NEON_CYAN = new Color(56, 189, 248);
    private static final Color NEON_GREEN = new Color(74, 222, 128);
    private static final Color NEON_AMBER = new Color(251, 191, 36);

    public GamePanel(Game game) {
        this.game = game;
        this.resultShown = false;
        setLayout(new BorderLayout(10, 10));
        setBackground(BG_DARK);
        setBorder(new EmptyBorder(10, 10, 10, 10));
        setFocusable(true);
        mazeCanvas = new MazeCanvas(game);

        createHeader();
        createMap();
        createControls();
        createFooter();
        configureKeyboard();

        mazeCanvas.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                mazeCanvas.requestFocusInWindow();
            }
        });

        timer = new Timer(250, e -> refresh());
        timer.start();
        refresh();
    }

    private void createHeader() {
        JPanel header = new JPanel(new BorderLayout(16, 0));
        header.setBackground(PANEL_BG);
        header.setBorder(new CompoundBorder(
                new LineBorder(BORDER_CYAN, 1, true),
                new EmptyBorder(10, 16, 10, 16)
        ));

        JPanel titleBox = new JPanel(new GridLayout(2, 1, 0, 2));
        titleBox.setOpaque(false);

        JLabel title = new JLabel("LABIRINTO DAS REDES // PACKET ESCAPE");
        title.setForeground(NEON_CYAN);
        title.setFont(new Font("Monospaced", Font.BOLD, 19));

        JLabel subtitle = new JLabel("MISSÃO: RECUPERE A CHAVE AES-256 E ALCANCE O GATEWAY ANTES DO RANSOMWARE");
        subtitle.setForeground(new Color(148, 163, 184));
        subtitle.setFont(new Font("SansSerif", Font.BOLD, 10));

        titleBox.add(title);
        titleBox.add(subtitle);

        JPanel telemetry = new JPanel(new GridLayout(1, 3, 12, 0));
        telemetry.setOpaque(false);
        telemetry.setPreferredSize(new Dimension(470, 42));

        hopsBar = createMetricBar("SALTOS (TTL)", NEON_CYAN);
        timeBar = createMetricBar("RANSOMWARE", NEON_AMBER);
        mtuBar = createMetricBar("CARGA MTU", NEON_GREEN);

        telemetry.add(hopsBar);
        telemetry.add(timeBar);
        telemetry.add(mtuBar);

        header.add(titleBox, BorderLayout.WEST);
        header.add(telemetry, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);
    }

    private JProgressBar createMetricBar(String title, Color fg) {
        JProgressBar bar = new JProgressBar(0, 100);
        bar.setStringPainted(true);
        bar.setForeground(fg);
        bar.setBackground(new Color(10, 15, 28));
        bar.setFont(new Font("Monospaced", Font.BOLD, 11));
        bar.setBorder(BorderFactory.createTitledBorder(
                new LineBorder(BORDER_CYAN, 1),
                title,
                0, 0,
                new Font("SansSerif", Font.BOLD, 9),
                new Color(148, 163, 184)
        ));
        return bar;
    }

    private void createMap() {
        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(BG_DARK);
        center.setBorder(new LineBorder(BORDER_CYAN, 1, true));
        center.add(mazeCanvas);
        add(center, BorderLayout.CENTER);
    }

    private void createControls() {
        JPanel sidePanel = new JPanel(new BorderLayout(0, 8));
        sidePanel.setPreferredSize(new Dimension(195, 0));
        sidePanel.setBackground(PANEL_BG);
        sidePanel.setBorder(new CompoundBorder(
                new LineBorder(BORDER_CYAN, 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        JLabel menuTitle = new JLabel("COMANDOS DO PACOTE", SwingConstants.CENTER);
        menuTitle.setForeground(NEON_CYAN);
        menuTitle.setFont(new Font("Monospaced", Font.BOLD, 12));
        sidePanel.add(menuTitle, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new GridLayout(9, 1, 6, 6));
        buttons.setOpaque(false);

        addCyberButton(buttons, "[+] Olhar Sala", new Color(30, 58, 95), () -> execute("olhar"));
        addCyberButton(buttons, "[↓] Pegar Item", new Color(22, 78, 99), this::takeItem);
        addCyberButton(buttons, "[↑] Soltar Item", new Color(30, 58, 95), this::dropItem);
        addCyberButton(buttons, "[≡] Inventário MTU", new Color(30, 58, 95), this::showInventory);
        addCyberButton(buttons, "[*] Usar Item", new Color(6, 95, 70), this::useItemDialog);
        addCyberButton(buttons, "[?] Resolver Desafio", new Color(120, 53, 15), this::solveChallenge);
        addCyberButton(buttons, "[!] Pedir Dica", new Color(30, 58, 95), () -> execute("dica"));
        addCyberButton(buttons, "[i] Manual / Legenda", new Color(30, 58, 95), this::showHelp);
        addCyberButton(buttons, "[↻] Reiniciar Rede", new Color(127, 29, 29), this::restartGame);

        sidePanel.add(buttons, BorderLayout.CENTER);

        JLabel legend = new JLabel("<html><center><font color='#94a3b8' size='2'>" +
                "Setas/WASD: Mover | <font color='#fbbf24'>■</font> Item | <font color='#ef4444'>●</font> Desafio" +
                "</font></center></html>", SwingConstants.CENTER);
        sidePanel.add(legend, BorderLayout.SOUTH);

        add(sidePanel, BorderLayout.EAST);
    }

    private void addCyberButton(JPanel panel, String text, Color bg, Runnable action) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFocusable(false);
        button.setBackground(bg);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Monospaced", Font.BOLD, 12));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(new CompoundBorder(
                new LineBorder(new Color(56, 189, 248, 120), 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));

        Color hover = bg.brighter();
        button.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { button.setBackground(hover); }
            @Override public void mouseExited(MouseEvent e) { button.setBackground(bg); }
        });

        button.addActionListener(e -> {
            action.run();
            mazeCanvas.requestFocusInWindow();
        });
        panel.add(button);
    }

    private void createFooter() {
        JPanel footer = new JPanel(new BorderLayout(8, 8));
        footer.setBackground(PANEL_BG);
        footer.setBorder(new CompoundBorder(
                new LineBorder(BORDER_CYAN, 1, true),
                new EmptyBorder(10, 14, 10, 14)
        ));

        JPanel locPanel = new JPanel(new BorderLayout());
        locPanel.setOpaque(false);

        roomLabel = new JLabel();
        roomLabel.setForeground(NEON_AMBER);
        roomLabel.setFont(new Font("Monospaced", Font.BOLD, 13));

        roomDetailLabel = new JLabel();
        roomDetailLabel.setForeground(new Color(203, 213, 225));
        roomDetailLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));

        locPanel.add(roomLabel, BorderLayout.WEST);
        locPanel.add(roomDetailLabel, BorderLayout.EAST);

        logArea = new JTextArea(4, 60);
        logArea.setEditable(false);
        logArea.setFocusable(false);
        logArea.setLineWrap(true);
        logArea.setWrapStyleWord(true);
        logArea.setBackground(new Color(6, 10, 19));
        logArea.setForeground(NEON_GREEN);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        logArea.setBorder(new EmptyBorder(6, 8, 6, 8));

        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setBorder(new LineBorder(BORDER_CYAN, 1));

        JPanel command = new JPanel(new BorderLayout(8, 0));
        command.setBackground(new Color(6, 10, 19));
        command.setBorder(new CompoundBorder(
                new LineBorder(NEON_CYAN, 1, true),
                new EmptyBorder(4, 8, 4, 8)
        ));

        JLabel prompt = new JLabel("root@pacote-ip:~#");
        prompt.setForeground(NEON_CYAN);
        prompt.setFont(new Font("Monospaced", Font.BOLD, 13));

        commandField = new JTextField();
        commandField.setBackground(new Color(6, 10, 19));
        commandField.setForeground(Color.WHITE);
        commandField.setCaretColor(NEON_GREEN);
        commandField.setBorder(null);
        commandField.setFont(new Font("Monospaced", Font.PLAIN, 13));
        commandField.addActionListener(e -> {
            execute(commandField.getText());
            commandField.setText("");
            mazeCanvas.requestFocusInWindow();
        });

        command.add(prompt, BorderLayout.WEST);
        command.add(commandField, BorderLayout.CENTER);

        footer.add(locPanel, BorderLayout.NORTH);
        footer.add(scrollPane, BorderLayout.CENTER);
        footer.add(command, BorderLayout.SOUTH);
        add(footer, BorderLayout.SOUTH);
    }

    private void configureKeyboard() {
        bindMove("UP", 0, -1);
        bindMove("DOWN", 0, 1);
        bindMove("LEFT", -1, 0);
        bindMove("RIGHT", 1, 0);

        bindCanvasKey("W", 0, -1);
        bindCanvasKey("S", 0, 1);
        bindCanvasKey("A", -1, 0);
        bindCanvasKey("D", 1, 0);
    }

    private void bindMove(String key, int dx, int dy) {
        String name = "move_" + key;
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key), name);
        getActionMap().put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!game.isFinished() && !commandField.isFocusOwner()) {
                    mazeCanvas.movePlayer(dx, dy);
                    refresh();
                }
            }
        });
    }

    private void bindCanvasKey(String key, int dx, int dy) {
        String name = "canvas_move_" + key;
        mazeCanvas.getInputMap(WHEN_FOCUSED).put(KeyStroke.getKeyStroke(key), name);
        mazeCanvas.getActionMap().put(name, new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!game.isFinished()) {
                    mazeCanvas.movePlayer(dx, dy);
                    refresh();
                }
            }
        });
    }

    private void execute(String command) {
        game.executeCommand(command);
        refresh();
    }

    private void showInventory() {
        JOptionPane.showMessageDialog(this, game.getPlayer().getInventoryString(),
                "Inventário do Pacote (MTU)", JOptionPane.INFORMATION_MESSAGE);
    }

    private void takeItem() {
        String available = game.getPlayer().getCurrentRoom().getItemString();
        String item = JOptionPane.showInputDialog(this,
                "Itens detectados nesta sala: " + available + "\nDigite o nome do item para coletar:");
        if (item != null && !item.isBlank()) {
            execute("pegar " + item.trim());
        }
    }

    private void dropItem() {
        String item = JOptionPane.showInputDialog(this,
                game.getPlayer().getInventoryString() + "\n\nQual item deseja soltar?");
        if (item != null && !item.isBlank()) {
            execute("soltar " + item.trim());
        }
    }

    private void useItemDialog() {
        String item = JOptionPane.showInputDialog(this,
                game.getPlayer().getInventoryString() + "\n\nQual item deseja usar? (ex: ping, log, qos)");
        if (item != null && !item.isBlank()) {
            execute("usar " + item.trim());
        }
    }

    private void solveChallenge() {
        NetworkChallenge challenge = game.getPlayer().getCurrentRoom().getChallenge();
        if (challenge == null) {
            JOptionPane.showMessageDialog(this, "Não há desafio de rede ativo nesta sala.");
            return;
        }
        String answer = JOptionPane.showInputDialog(this, challenge.getPrompt());
        if (answer != null && !answer.isBlank()) {
            game.solveChallenge(answer);
            refresh();
        }
    }

    private void showHelp() {
        JOptionPane.showMessageDialog(this,
                "MAPA TÁTICO:\n" +
                "• Quadrado Dourado = Item na sala | Círculo Vermelho (!) = Desafio de rede\n" +
                "• Vermelho = Sala Trancada (Firewall/Gateway) | Verde = Desbloqueada\n" +
                "• Amarelo = Roteador Defeituoso (+3 saltos) | Roxo = Túnel Proxy Aleatório\n\n" +
                "COMANDOS NO TERMINAL:\n" +
                "• ir norte | ir sul | ir leste | ir oeste (ou Setas / WASD)\n" +
                "• pegar <item> | soltar <item> | usar <item> | inventario\n" +
                "• responder <resposta> | olhar | dica | sair",
                "Manual de Operações — Labirinto das Redes", JOptionPane.INFORMATION_MESSAGE);
    }

    private void restartGame() {
        game.resetGame();
        mazeCanvas.clearTrail();
        resultShown = false;
        if (timer != null && !timer.isRunning()) {
            timer.start();
        }
        refresh();
        mazeCanvas.requestFocusInWindow();
    }

    private void refresh() {
        int hops = game.getHops();
        int maxHops = game.getMaxHops();
        hopsBar.setMaximum(maxHops);
        hopsBar.setValue(Math.min(hops, maxHops));
        hopsBar.setString(hops + " / " + maxHops + " saltos");
        hopsBar.setForeground(hops > maxHops * 0.75 ? new Color(239, 68, 68) : NEON_CYAN);

        int remSec = game.getRemainingSeconds();
        timeBar.setMaximum(240);
        timeBar.setValue(remSec);
        timeBar.setString(remSec + "s restantes");
        timeBar.setForeground(remSec <= 45 ? new Color(239, 68, 68) : NEON_AMBER);

        int weight = game.getPlayer().getCurrentWeight();
        int mtu = game.getPlayer().getMtu();
        mtuBar.setMaximum(mtu);
        mtuBar.setValue(weight);
        mtuBar.setString(weight + " / " + mtu + " B");
        mtuBar.setForeground(weight >= mtu ? new Color(239, 68, 68) : NEON_GREEN);

        Room current = game.getPlayer().getCurrentRoom();
        roomLabel.setText("NÓ ATUAL: " + current.getName().toUpperCase());
        roomDetailLabel.setText("Saídas: [" + current.getExitsDescription() + "]  |  Itens: [" + current.getItemString() + "]");

        logArea.setText(String.join("\n", game.getEventLog()));
        logArea.setCaretPosition(logArea.getDocument().getLength());
        mazeCanvas.repaint();

        if (game.isFinished() && !resultShown) {
            resultShown = true;
            if (timer != null) timer.stop();
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, game.getStatus(),
                        game.isVictory() ? "MISSÃO CONCLUÍDA!" : "SISTEMA CRIPTOGRAFADO (GAME OVER)",
                        game.isVictory() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
                mazeCanvas.requestFocusInWindow();
            });
        }
    }
}

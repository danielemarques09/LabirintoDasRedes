import java.util.LinkedHashMap;
import java.util.Map;

public class Room {
    private final String name;
    private final String description;
    private final Map<String, Room> exits = new LinkedHashMap<>();
    private final Map<String, Item> items = new LinkedHashMap<>();
    private NetworkChallenge challenge;

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void setExit(String direction, Room room) {
        exits.put(direction.toLowerCase(), room);
    }

    public Room getExit(String direction) {
        return exits.get(direction.toLowerCase());
    }

    public boolean hasExitTo(Room room) {
        return exits.containsValue(room);
    }

    public String getExitsDescription() {
        return exits.isEmpty() ? "nenhuma" : String.join(", ", exits.keySet());
    }

    public void addItem(Item item) {
        items.put(item.getName().toLowerCase(), item);
    }

    public Item getItem(String name) {
        return name == null ? null : items.get(name.trim().toLowerCase());
    }

    public Item removeItem(String name) {
        return name == null ? null : items.remove(name.trim().toLowerCase());
    }

    public boolean hasItems() {
        return !items.isEmpty();
    }

    public String getItemString() {
        if (items.isEmpty()) {
            return "Nenhum item no chão.";
        }
        StringBuilder sb = new StringBuilder();
        for (Item item : items.values()) {
            if (!sb.isEmpty()) sb.append(", ");
            sb.append(item.getName()).append(" (").append(item.getWeight()).append("B)");
        }
        return sb.toString();
    }

    public void setChallenge(NetworkChallenge challenge) {
        this.challenge = challenge;
    }

    public NetworkChallenge getChallenge() {
        return challenge;
    }

    public boolean canEnter(Player player) {
        return true;
    }

    public String getBlockedMessage() {
        return "Acesso negado a esta sala.";
    }

    public String onEnter(Player player, Game game) {
        String msg = "Você entrou em: " + name + ".";
        if (challenge != null && !challenge.isSolved()) {
            msg += " [DESAFIO]: " + challenge.getPrompt();
        }
        return msg;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getLongDescription() {
        StringBuilder sb = new StringBuilder();
        sb.append("Sala: ").append(name).append("\n");
        sb.append(description).append("\n");
        sb.append("Saídas: ").append(getExitsDescription()).append("\n");
        sb.append("Itens na sala: ").append(getItemString());
        if (challenge != null) {
            sb.append("\nDesafio de Rede: ")
              .append(challenge.isSolved() ? "[RESOLVIDO] " : "[PENDENTE] ")
              .append(challenge.getPrompt());
        }
        return sb.toString();
    }
}

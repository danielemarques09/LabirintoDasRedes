public class SecurityKey extends Item {
    public SecurityKey() {
        super("chave", "Chave mestra AES-256 para autenticar e escapar pelo Gateway", 15);
    }

    @Override
    public String use(Player player, Game game) {
        if (player.getCurrentRoom().getName().toLowerCase().contains("servidor")) {
            return "Chave AES-256 validada! Leve-a até o Gateway de Saída para concluir a missão.";
        }
        return "A chave AES-256 está pronta. Leve-a até a porta do Gateway para escapar da rede.";
    }
}

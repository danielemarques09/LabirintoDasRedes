public class PacketBoosterItem extends ConsumableItem {
    public PacketBoosterItem() {
        super("qos", "Priorizador de tráfego QoS: otimiza rota e recupera 8 saltos antes do ransomware", 8);
    }

    @Override
    protected String applyEffect(Player player, Game game) {
        game.reduceHops(8);
        return "QoS ativado! Tráfego priorizado na rede: -8 saltos consumidos.";
    }
}

public class CorruptedLogItem extends Item {
    private final String logContent;

    public CorruptedLogItem() {
        super("log", "Arquivo de log corrompido recuperado do roteador", 10);
        this.logContent = "[LOG_SYS_DUMP]: Gateway padrão = 192.168.10.254 | Sub-rede = /24 | Porta segura = 443";
    }

    @Override
    public String use(Player player, Game game) {
        return "Leitura do Log: " + logContent;
    }
}

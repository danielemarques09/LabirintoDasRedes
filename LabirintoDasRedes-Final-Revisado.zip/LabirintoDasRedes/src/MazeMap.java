import java.awt.Point;
import java.util.Map;

public class MazeMap {
    public static final int ROWS = 13;
    public static final int COLS = 25;
    private final int[][] roomAt = new int[ROWS][COLS];

    private final Map<Integer, Point> roomCenters = Map.of(
            0, new Point(2, 2),
            1, new Point(5, 2),
            2, new Point(9, 2),
            3, new Point(10, 5),
            4, new Point(6, 6),
            5, new Point(14, 6),
            6, new Point(19, 6),
            7, new Point(14, 2),
            8, new Point(10, 9)
    );

    public MazeMap() {
        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                roomAt[y][x] = -1;
            }
        }

        fill(1, 1, 3, 3, 0);
        fill(4, 2, 7, 2, 1);
        roomAt[3][6] = 1;
        roomAt[4][6] = 1;
        fill(8, 1, 11, 3, 2);
        roomAt[2][12] = 7;
        fill(13, 1, 16, 3, 7);
        fill(9, 4, 11, 6, 3);
        roomAt[7][10] = 8;
        fill(9, 8, 11, 10, 8);
        fill(5, 5, 7, 7, 4);
        fill(12, 5, 16, 7, 5);
        roomAt[6][17] = 5;
        fill(18, 5, 21, 7, 6);

        roomAt[1][1] = -1;
        roomAt[3][3] = -1;
        roomAt[1][9] = -1;
        roomAt[1][15] = -1;
        roomAt[5][5] = -1;
        roomAt[7][7] = -1;
        roomAt[5][13] = -1;
        roomAt[7][15] = -1;
        roomAt[5][19] = -1;
    }

    private void fill(int x1, int y1, int x2, int y2, int roomIndex) {
        for (int y = y1; y <= y2; y++) {
            for (int x = x1; x <= x2; x++) {
                roomAt[y][x] = roomIndex;
            }
        }
    }

    public boolean isWalkable(int x, int y) {
        return x >= 0 && x < COLS && y >= 0 && y < ROWS && roomAt[y][x] >= 0;
    }

    public int getRoomIndex(int x, int y) {
        return isWalkable(x, y) ? roomAt[y][x] : -1;
    }

    public Point getRoomCenter(int roomIndex) {
        return roomCenters.getOrDefault(roomIndex, new Point(2, 2));
    }

    public int getRows() {
        return ROWS;
    }

    public int getCols() {
        return COLS;
    }
}

public class JunkPacketItem extends Item {
    public JunkPacketItem() {
        super("dump", "Pacote de broadcast pesado (ocupa 25 bytes de MTU sem utilidade)", 25);
    }

    @Override
    public String use(Player player, Game game) {
        return "Este arquivo contém apenas ruído de broadcast. Considere usar 'soltar dump' para liberar MTU!";
    }
}

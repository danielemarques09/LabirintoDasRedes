public class FaultyRouterRoom extends Room {
    private final int hopPenalty;

    public FaultyRouterRoom(String name, String description, int hopPenalty) {
        super(name, description);
        this.hopPenalty = hopPenalty;
    }

    @Override
    public String onEnter(Player player, Game game) {
        game.addPenaltyHops(hopPenalty);
        return "ALERTA DE HARDWARE em " + getName() + "! Pacote sofreu retransmissão (+" + hopPenalty + " saltos).";
    }
}
